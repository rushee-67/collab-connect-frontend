# `nvm` Project Governance

## Maintainers
  - [@ljharb](https://github.com/ljharb)

Maintainers are responsible for issue/PR triage, feature additions, maintenance, bugfixes, security fixes, releases, promoting existing contributors to maintainers, managing repo and CI configuration, etc.

## Contributors

Anyone who contributes code or content or time, via issues or pull requests or otherwise. Contributors do not have any additional permissions on the project.
